from scapy.all import *
from datetime import datetime
import threading

# 定义全局变量，用于控制嗅探线程
sniffing = True

def packet_handler(packet):
    """处理捕获的数据包，只处理入网流量"""
    if IP in packet and (TCP in packet or UDP in packet):
        # 获取当前时间
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 获取源和目的 IP
        src_ip = packet[IP].src
        dst_ip = packet[IP].dst
        
        # 获取源和目的 MAC 地址
        src_mac = packet.src
        dst_mac = packet.dst
        
        # 获取协议类型和端口
        if TCP in packet:
            protocol = "TCP"
            src_port = packet[TCP].sport
            dst_port = packet[TCP].dport
        else:  # UDP
            protocol = "UDP"
            src_port = packet[UDP].sport
            dst_port = packet[UDP].dport
            
        # 只处理入网流量（目标端口匹配指定端口）
        if dst_port == target_port:
            # 格式化输出
            # print(f"Time: {current_time}")
            # print(f"Protocol: {protocol}")
            # print(f"Source: {src_mac} ({src_ip}:{src_port})")
            # print(f"Destination: {dst_mac} ({dst_ip}:{dst_port})")
            # print(f"Length: {len(packet)} bytes")
            # print("-" * 50)
            print(packet)

def start_sniffing(interface, port):
    """开始嗅探指定端口的入网流量"""
    global sniffing, target_port
    target_port = port  # 设置全局目标端口
    try:
        print(f"开始监控 {interface} 接口上端口 {port} 的入网流量...")
        print("按 Ctrl+C 停止监控")
        # 设置过滤规则，只捕获目标端口的流量
        filter_rule = f"dst port {port}"
        # 开始嗅探
        sniff(iface=interface, 
              filter=filter_rule, 
              prn=packet_handler, 
              store=0)
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        sniffing = False

def main():
    # 获取用户输入
    interface = input("请输入网络接口名称（例如 eth0, wlan0）: ")
    try:
        port = int(input("请输入要监控的端口号: "))
        if not (0 <= port <= 65535):
            raise ValueError("端口号必须在 0-65535 之间")
    except ValueError as e:
        print(f"无效的端口号: {e}")
        return

    # 创建嗅探线程
    sniff_thread = threading.Thread(
        target=start_sniffing,
        args=(interface, port)
    )
    
    # 启动嗅探线程
    sniff_thread.start()
    
    try:
        # 主线程等待用户中断
        while sniff_thread.is_alive():
            sniff_thread.join(1)
    except KeyboardInterrupt:
        print("\n正在停止监控...")
        global sniffing
        sniffing = False
        sniff_thread.join()

if __name__ == "__main__":
    # 检查是否以管理员/root权限运行
    if os.name == 'posix' and os.geteuid() != 0:
        print("此程序需要root权限运行，请使用sudo执行")
    elif os.name == 'nt':
        print("此程序在Windows下需要管理员权限运行")
    else:
        main()