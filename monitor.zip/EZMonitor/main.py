from scapy.all import *
import os
import csv
from datetime import datetime
import threading
import argparse
import sys
import ipaddress
from collections import defaultdict

# 全局变量
sniffing = True
target_ports = []

class TrafficLogger:
    def __init__(self, log_dir):
        self.log_dir = log_dir
        self.traffic_records = defaultdict(lambda: {"count": 0, "first_time": None})

    def get_log_path(self):
        current_year_month = datetime.now().strftime("%Y-%m")
        log_subdir = os.path.join(self.log_dir, current_year_month)
        os.makedirs(log_subdir, exist_ok=True)
        return os.path.join(log_subdir, f"traffic_{datetime.now().strftime('%Y%m%d')}.csv")

    def save_to_csv(self):
        log_file = self.get_log_path()
        with open(log_file, 'a', newline='') as f:
            csv_writer = csv.writer(f)
            if os.path.getsize(log_file) == 0:
                csv_writer.writerow(["Time", "Source_IP", "Source_Port", "Dest_Port", "Source_MAC", "Protocol", "Request_Count"])
            for key, data in self.traffic_records.items():
                time, src_ip, src_port, dst_port, src_mac, protocol = key
                csv_writer.writerow([data["first_time"], src_ip, src_port, dst_port, src_mac, protocol, data["count"]])
            self.traffic_records.clear()  # 清空记录，准备下次写入

def is_private_ip(ip):
    """检查 IP 是否为内网地址"""
    private_networks = [
        ipaddress.IPv4Network("10.0.0.0/8"),
        ipaddress.IPv4Network("172.16.0.0/12"),
        ipaddress.IPv4Network("192.168.0.0/16")
    ]
    try:
        ip_obj = ipaddress.ip_address(ip)
        return any(ip_obj in network for network in private_networks)
    except ValueError:
        return False

def get_network_interfaces():
    """获取当前系统的网卡列表"""
    try:
        ifaces = get_if_list()
        if not ifaces:
            raise Exception("未找到可用网卡")
        return ifaces
    except Exception as e:
        print(f"获取网卡列表失败: {e}")
        sys.exit(1)

def packet_handler(packet, logger):
    """处理捕获的数据包，只记录外部 IP 和指定端口的入网流量"""
    if IP in packet and (TCP in packet or UDP in packet):
        # 获取源 IP
        src_ip = packet[IP].src
        
        # 只记录外部 IP
        if not is_private_ip(src_ip):
            # 获取协议类型和端口
            if TCP in packet:
                protocol = "TCP"
                src_port = packet[TCP].sport
                dst_port = packet[TCP].dport
            else:  # UDP
                protocol = "UDP"
                src_port = packet[UDP].sport
                dst_port = packet[UDP].dport
            
            # 只记录目标端口在指定列表中的流量
            if dst_port in target_ports:
                current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                src_mac = packet.src
                
                # 使用元组作为键，包含所有关键字段
                key = (current_time, src_ip, src_port, dst_port, src_mac, protocol)
                if key not in logger.traffic_records:
                    logger.traffic_records[key]["first_time"] = current_time
                logger.traffic_records[key]["count"] += 1

def start_sniffing(interface, log_dir):
    """开始嗅探指定端口的入网流量并定期记录到 CSV"""
    global sniffing
    logger = TrafficLogger(log_dir)
    try:
        print(f"开始监控 {interface or '所有网卡'} 上端口 {target_ports} 的入网流量（仅外部 IP，折叠重复记录）...")
        print(f"日志保存至: {logger.get_log_path()}")
        print("按 Ctrl+C 停止监控")
        
        # 设置过滤规则，只捕获指定端口的流量
        filter_rule = " or ".join(f"dst port {port}" for port in target_ports)
        while sniffing:
            sniff(iface=interface, 
                  filter=filter_rule,
                  prn=lambda pkt: packet_handler(pkt, logger),
                  store=0,
                  timeout=5)  # 每 60 秒写入一次
            logger.save_to_csv()
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        logger.save_to_csv()  # 退出时保存剩余记录
        sniffing = False

def main():
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="网络流量监控程序（仅记录外部 IP 和指定端口，折叠重复记录）")
    parser.add_argument("--log-dir", type=str, default=os.getcwd(), help="日志保存的根目录")
    parser.add_argument("--ports", type=int, nargs="+", required=True, help="要监控的端口号（多个端口用空格分隔）")
    args = parser.parse_args()

    # 设置目标端口
    global target_ports
    target_ports = args.ports
    for port in target_ports:
        if not (0 <= port <= 65535):
            print(f"错误：端口号 {port} 无效，必须在 0-65535 之间")
            sys.exit(1)

    # 获取网卡列表
    interfaces = get_network_interfaces()
    print("可用网卡列表：")
    for i, iface in enumerate(interfaces):
        print(f"{i}: {iface}")
    print("-1: 监控所有网卡")

    # 用户选择网卡
    while True:
        try:
            choice = int(input("请选择网卡索引（-1 表示所有网卡）: "))
            if choice == -1:
                selected_interface = None
                break
            elif 0 <= choice < len(interfaces):
                selected_interface = interfaces[choice]
                break
            else:
                print("无效的索引，请重新选择")
        except ValueError:
            print("请输入有效的数字")

    # 创建嗅探线程
    sniff_thread = threading.Thread(
        target=start_sniffing,
        args=(selected_interface, args.log_dir)
    )
    
    # 启动嗅探线程
    sniff_thread.start()
    
    try:
        # 主线程等待用户中断
        while sniff_thread.is_alive():
            sniff_thread.join(1)
    except KeyboardInterrupt:
        print("\n正在停止监控...")
        global sniffing
        sniffing = False
        sniff_thread.join()

if __name__ == "__main__":
    if os.name == 'posix' and os.geteuid() != 0:
        print("此程序需要 root 权限运行，请使用 sudo 执行")
        sys.exit(1)
    elif os.name == 'nt':
        print("此程序在 Windows 下需要管理员权限运行")
        sys.exit(1)
    else:
        main()